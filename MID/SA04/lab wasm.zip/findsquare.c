int square(int n) {
 return n*n;
}
